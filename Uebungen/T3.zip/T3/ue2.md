Mit dem Port 443 geht es mit HTTPS, beim Port 80 wird man auf die HTTPS Seite weitergeleitet.
Alle anderen Ports gehen nicht, mit HTTP oder HTTPS.