1. Analyse der Requests:
    - GET-Request: Fordert den HTML-Code des Formulars vom Server an.
    - POST-Request: Sendet die Formulardaten an den Server und erhält eine Antwort.

2. Antwort im POST-Request:
   Die Antwort kann eine Erfolgsmeldung oder eine Fehlermeldung enthalten, je nach Ergebnis der Verarbeitung.

3. F5 drücken und Bestätigungsnachricht:
   Die Bestätigungsnachricht bedeutet, dass der Browser den letzten POST-Request erneut senden möchte.

4. Bedeutung der Einstellung "Preserve log":
   Netzwerkaktivitäten bleiben beim Neuladen der Seite oder bei Navigationen erhalten.

5. Bedeutung der Einstellung "Doc":
   Zeigt nur Dokument-Requests an, hilft, sich auf die Hauptdokumente zu konzentrieren.
