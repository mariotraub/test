Die Inhaltstypen der Header stimmen mit den wirklichen Antworten überein. 
Es wird auch noch das Charset angegeben, also meistens utf-8.
