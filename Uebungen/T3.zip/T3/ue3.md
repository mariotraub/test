https://gitlab.com/ch-tbz-it/Stud/m293g/m293/-/blob/main/T3_Protokoll/Uebungen.md#%C3%BCbung-3---anker
Es gibt einen Link neben jedem Titel, alternativ könnte man mit den Dev-Tools die ID des Titels herausfinden und sie nach dem "#" in der URL platzieren.
